package com.example.lab2;

import android.os.Bundle;
import android.widget.CompoundButton; // Import générique pour Switch et Checkbox
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText surfaceInput, piecesInput;
    private CompoundButton piscineSwitch; // Le nom déclaré est piscineSwitch
    private TextView resultView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surfaceInput = findViewById(R.id.input_surface);
        piecesInput = findViewById(R.id.input_pieces);

        // CORRECTION ICI : On utilise le nom "piscineSwitch"
        piscineSwitch = findViewById(R.id.checkbox_piscine);

        resultView = findViewById(R.id.result);

        findViewById(R.id.button_calcul).setOnClickListener(v -> calculer());
    }

    private void calculer() {
        String surfaceStr = surfaceInput.getText().toString();
        String piecesStr = piecesInput.getText().toString();

        if (surfaceStr.isEmpty() || piecesStr.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        double surface = Double.parseDouble(surfaceStr);
        int pieces = Integer.parseInt(piecesStr);

        // CORRECTION ICI : On utilise aussi "piscineSwitch"
        boolean piscine = piscineSwitch.isChecked();

        double impotBase = surface * 2;
        double supplement = pieces * 50 + (piscine ? 100 : 0);
        double total = impotBase + supplement;

        resultView.setText(String.format("%.2f DH", total));
    }
}